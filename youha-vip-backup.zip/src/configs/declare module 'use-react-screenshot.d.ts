declare module 'use-react-screenshot';
