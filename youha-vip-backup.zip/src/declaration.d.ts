declare namespace JSX {
    interface IntrinsicElements {
        "lottie-player": any;
    }
}