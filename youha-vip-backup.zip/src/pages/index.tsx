import { alpha, Box, Button, ButtonBase } from "@mui/material";
import dynamic from "next/dynamic";
import Typo from "../components/atoms/Typo";
const ReactPlayer = dynamic(() => import("react-player"), { ssr: false });

export default function Page() {
  return (
    <Box>
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: 56,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 99,
          background: `linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0))`,
          "& img": {
            width: "auto",
            height: 24,
          },
        }}
      >
        <img src="/images/logo/collab-white.png" />
      </Box>
      <ButtonBase
        sx={{
          position: "fixed",
          left: 16,
          right: 16,
          bottom: 16,
          zIndex: 999,
          height: 44,
          backgroundColor: "#ffffff",
        }}
      >
        <Typo>구글 계정으로 로그인</Typo>
      </ButtonBase>
      <Box
        sx={{
          position: "relative",
          height: "100vh",
          "& video": {
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            objectFit: "cover",
          },
        }}
      >
        <ReactPlayer
          url="https://jellysmack.com/wp-content/uploads/2022/02/ADDTL_jellysmack_longform_1920x1080_SANSattribution.mp4"
          playing
          muted
          loop
        />
        <Box
          sx={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: alpha("#000000", 0.6),
          }}
        ></Box>
      </Box>
    </Box>
  );
}
