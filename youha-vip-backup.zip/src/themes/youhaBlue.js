const youhaBlue = {
  50: "#e9ecfe",
  100: "#c8cffd",
  200: "#a1affc",
  300: "#768ffb",
  400: "#5074f9",
  500: "#1c5af6",
  600: "#1451ea",
  700: "#0046dd",
  800: "#003ad2",
  900: "#0023c1",
  A100: "#cfd8dc",
  A200: "#cfd8dc",
  A400: "#cfd8dc",
  A700: "#cfd8dc",
};
export default youhaBlue;
